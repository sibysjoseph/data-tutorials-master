#!/bin/bash
sqoop import --connect jdbc:mysql://localhost/test --table test_table_sqoop1 --hive-import --hive-table test_hive_table1 --username root -P -m 1 --fetch-size 1 
