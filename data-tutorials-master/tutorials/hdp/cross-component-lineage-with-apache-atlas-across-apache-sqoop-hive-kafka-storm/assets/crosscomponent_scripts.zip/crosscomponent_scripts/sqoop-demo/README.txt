#
#
#  This demo will show the lineage of data between sqoop and hive tables
#

#
# Create a mysql table
# ** default password is blank
#
cat 001-setup-mysql.sql | mysql -u root -p 

#
# Run the SQOOP Job
# ** default password is blank
#
sh 002-run-sqoop-import.sh

#
# Create CTAS sql command
#
cat 003-ctas-hive.sql | beeline -u "jdbc:hive2://localhost:10000/default" -n hive -p hive -d org.apache.hive.jdbc.HiveDriver
