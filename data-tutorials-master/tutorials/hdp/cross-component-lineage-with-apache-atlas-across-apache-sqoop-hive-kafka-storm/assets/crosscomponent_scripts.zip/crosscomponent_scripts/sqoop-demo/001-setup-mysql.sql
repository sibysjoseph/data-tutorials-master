create database test;
use test ;
create table test_table_sqoop1 ( name char(25), location char(64) ) ;
insert into test_table_sqoop1 values ( 'Steve Job', 'San Fransisco,CA') ;
insert into test_table_sqoop1 values ( 'Mike Smith', 'London,UK') ;
