#!/bin/bash
/usr/hdp/current/kafka-broker/bin/kafka-topics.sh --create --topic my-topic-01 --zookeeper localhost:2181 --partitions 1 --replication-factor 1
