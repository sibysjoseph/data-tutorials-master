#
#
#  This demo will show the lineage of data between Kafka TOPIC (mytopic@erietp) to STORM topology (erie_demo_topology),
#  which stores the output in the HDFS folder (/user/storm/storm-hdfs-test)
#

#
# Create a Kafka topic to be used in the demo
#
001-create_topic.sh

#
# Create a HDFS folder for output
#
002-create-hdfs-outdir.sh

#
# Download STORM job jar file - Source is available at https://github.com/yhemanth/storm-samples 
#
003-download-storm-sample.sh

#
# Run the Storm JOB 
#
004-run-storm-job.sh

#
# View ATLAS UI for the lineage
#
#  http://localhost:21000/
#
#  Search for: kafka_topic-01
#  Click on: my-topic-01@erietp
#
#

