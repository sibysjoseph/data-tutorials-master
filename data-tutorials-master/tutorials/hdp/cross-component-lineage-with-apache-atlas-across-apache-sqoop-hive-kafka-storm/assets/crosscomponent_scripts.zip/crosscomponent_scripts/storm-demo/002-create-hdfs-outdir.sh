#!/bin/bash
HADOOP_USER_NAME=hdfs hdfs dfs -mkdir -p /user/storm/storm-hdfs-test-01
