#!/bin/bash
echo "Storm Jar file is already download in /root/crosscomponent_demo/crosscomponent_scripts/storm-demo/lib folder"
echo "You can view the source for this at https://github.com/yhemanth/storm-samples "
